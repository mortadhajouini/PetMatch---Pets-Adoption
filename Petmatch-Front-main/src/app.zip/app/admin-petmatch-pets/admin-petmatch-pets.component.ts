import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-petmatch-pets',
  templateUrl: './admin-petmatch-pets.component.html',
  styleUrls: ['./admin-petmatch-pets.component.css']
})
export class AdminPetmatchPetsComponent {
  isOwner = true; // Simulate the user being an owner
  isManager = false; // Simulate the user not being a manager

  // Simulated list of pets
  pets = [
    {
      id: 1,
      name: 'Max',
      species: 'Dog',
      age: 4,
      specificNeeds: 'None',
      guardType: 'temporary',
      imageUrl: 'assets/mortadha.jpg', // Add image URL
      owner:'Brahim'
    },
    {
      id: 2,
      name: 'Bella',
      species: 'Cat',
      age: 2,
      specificNeeds: 'Food allergies',
      guardType: 'definitive',
      imageUrl: 'assets/cat-sitting.jpg', // Add image URL
      owner:'sedki'
    },
    {
      id: 3,
      name: 'Charlie',
      species: 'Rabbit',
      age: 3,
      specificNeeds: 'Avoid sunlight',
      guardType: 'temporary',
      imageUrl: 'assets/b2.jpg', // Add image URL
      owner:'sedki'
    }
  ];

  constructor(private router: Router) {}

  ngOnInit(): void {}

  // Remove a pet from the list
  removePet(petId: number) {
    const confirmation = confirm('Are you sure you want to remove this pet?');
    if (confirmation) {
      this.pets = this.pets.filter(pet => pet.id !== petId);
    }
  }

}
