// on-hold-appointments.component.ts
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-on-hold-appointments',
  templateUrl: './on-hold-appointments.component.html',
  styleUrls: ['./on-hold-appointments.component.css']
})
export class OnHoldAppointmentsComponent implements OnInit {
  onHoldAppointments = [
    { title: 'Scheduled Grooming', petName: 'Charlie', status: 'On Hold' },
    { title: 'Checkup',  petName: 'Luna', status: 'On Hold' },
  ];

  constructor() {}

  ngOnInit(): void {}
}
