import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-edit-profile',
  templateUrl: './admin-edit-profile.component.html',
  styleUrls: ['./admin-edit-profile.component.css']
})
export class AdminEditProfileComponent {
  userName = 'Admin';
  userEmail = 'Admin@example.com';
  userRole = 'Owner'; // Initial role value

  isOwner = true;
  isManager = false;

  constructor() { }

  ngOnInit(): void {
    
  }

  // Save the updated profile details
  saveProfile() {
    alert('Profile updated successfully!');
    // Add logic to save updated profile (e.g., send to backend)
  }

  // Cancel the editing and go back
  cancelEditing() {
    alert('Editing canceled!');
    // Add logic to navigate back to profile page or previous page
  }
}
