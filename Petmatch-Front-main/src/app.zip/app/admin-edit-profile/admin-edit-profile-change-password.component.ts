import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './admin-edit-profile-change-password.component.html',
  styleUrls: ['./admin-edit-profile.component.css']
})
export class AdminEditProfileChangePasswordComponent implements OnInit {
  currentPassword = '';
  newPassword = '';
  newPasswordConfirm = '';


  constructor() { }

  ngOnInit(): void {
    
  }

  // Save the updated profile details
  saveProfile() {
    alert('Password updated successfully!');
    // Add logic to save updated profile (e.g., send to backend)
  }

  // Cancel the editing and go back
  cancelEditing() {
    alert('Editing Password canceled!');
    // Add logic to navigate back to profile page or previous page
  }
}
