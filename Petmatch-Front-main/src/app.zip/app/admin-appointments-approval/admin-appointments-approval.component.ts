import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-appointments-approval',
  templateUrl: './admin-appointments-approval.component.html',
  styleUrls: ['./admin-appointments-approval.component.css']
})
export class AdminAppointmentsApprovalComponent implements OnInit {
  appointment: any; // To hold the appointment data
  approvedDate: string = ''; // Selected date
  approvedTime: string = ''; // Selected time

  constructor(private router: Router) {
    // Retrieve the appointment data from state
    const navigation = this.router.getCurrentNavigation();
    this.appointment = navigation?.extras.state?.['appointment'];
  }

  ngOnInit(): void {}

  // Function to submit approval
  submitApproval() {
    if (this.approvedDate && this.approvedTime) {
      alert(`Appointment for '${this.appointment.title}' approved on ${this.approvedDate} at ${this.approvedTime}`);
      // Logic to send the approved date and time to the backend
      this.router.navigate(['/admin-appointments-requests']); // Navigate back after approval
    } else {
      alert('Please select both date and time.');
    }
  }
}
