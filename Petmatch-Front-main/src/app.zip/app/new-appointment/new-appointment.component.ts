import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-appointment',
  templateUrl: './new-appointment.component.html',
  styleUrls: ['./new-appointment.component.css']
})
export class NewAppointmentComponent {
  appointment = {
    title: '',
    notes: ''
  };

  constructor(private router: Router) {}

  submitForm() {
     // Mock saving appointment data
  alert('Appointment Created Successfully!');
  this.router.navigate(['/rendezvous']); // Redirect to Appointments page
  }
}
