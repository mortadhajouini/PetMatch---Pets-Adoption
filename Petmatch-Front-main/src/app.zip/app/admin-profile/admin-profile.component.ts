import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-profile',
  templateUrl: './admin-profile.component.html',
  styleUrls: ['./admin-profile.component.css']
})
export class AdminProfileComponent {
userName = 'Admin';
userEmail = 'Admin@example.com';


ngOnInit() {
  
}

editProfile() {
  alert('Edit profile functionality to be implemented.');
}
}
