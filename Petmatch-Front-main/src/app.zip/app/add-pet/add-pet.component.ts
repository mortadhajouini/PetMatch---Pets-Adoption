import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-pet',
  templateUrl: './add-pet.component.html',
  styleUrls: ['./add-pet.component.css']
})
export class AddPetComponent {
  pet = {
    name: '',
    species: '',
    age: null,
    specificNeeds: '',
    guardType: 'temporary',
    imageUrl: ''  // To store the image URL
  };

  constructor(private router: Router) {}

  // Handle file input change event to capture the selected image
  onImageSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      // Create a URL for the selected file
      this.pet.imageUrl = URL.createObjectURL(file);
    }
  }

  // Simulate adding a pet and redirect to the My Pets page
  addPet() {
    // Mock adding pet to the list
    console.log('New Pet Added:', this.pet);

    // Optionally, navigate to the My Pets page or reset the form
    this.router.navigate(['/my-pets']);
  }
}
