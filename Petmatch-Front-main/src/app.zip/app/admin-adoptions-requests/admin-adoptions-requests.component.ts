import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-adoptions-requests',
  templateUrl: './admin-adoptions-requests.component.html',
  styleUrls: ['./admin-adoptions-requests.component.css']
})
export class AdminAdoptionsRequestsComponent implements OnInit {
  // Sample data for adoption requests
  adoptionRequests = [
    {
      id: 1,
      petName: 'Max',
      species: 'Dog',
      userName: 'John Doe',
      date: '2024-12-01',
      imageUrl: 'assets/dog1.jpg'
    },
    {
      id: 2,
      petName: 'Bella',
      species: 'Cat',
      userName: 'Jane Smith',
      date: '2024-12-05',
      imageUrl: 'assets/cat-sitting.jpg'
    },
    {
      id: 3,
      petName: 'Charlie',
      species: 'Rabbit',
      userName: 'Chris Evans',
      date: '2024-12-10',
      imageUrl: 'assets/b2.jpg'
    }
  ];
  

  constructor() {}

  ngOnInit(): void {}

  // Function to accept an adoption request
  acceptRequest(request: any) {
    alert(`Adoption request for '${request.petName}' by ${request.userName} has been accepted.`);
    this.adoptionRequests = this.adoptionRequests.filter(r => r.id !== request.id);
    // Backend logic to mark the request as accepted
  }

  // Function to decline an adoption request
  declineRequest(request: any) {
    alert(`Adoption request for '${request.petName}' by ${request.userName} has been declined.`);
    this.adoptionRequests = this.adoptionRequests.filter(r => r.id !== request.id);
    // Backend logic to mark the request as declined
  }
}
