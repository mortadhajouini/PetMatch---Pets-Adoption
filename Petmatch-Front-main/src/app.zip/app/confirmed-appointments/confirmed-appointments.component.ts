// confirmed-appointments.component.ts
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmed-appointments',
  templateUrl: './confirmed-appointments.component.html',
  styleUrls: ['./confirmed-appointments.component.css']
})
export class ConfirmedAppointmentsComponent implements OnInit {
  confirmedAppointments = [
    { title: 'Vet Checkup', date: '2024-12-10', time: '9:00 AM', petName: 'Max', status: 'Confirmed' },
    { title: 'Follow-up Visit', date: '2024-12-15', time: '11:00 AM', petName: 'Bella', status: 'Confirmed' },
  ];

  constructor() {}

  ngOnInit(): void {}
}
