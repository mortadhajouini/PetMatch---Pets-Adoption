import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  userName = 'John Doe';
  userEmail = 'johndoe@example.com';
  userRole = 'Owner'; // Initial role value

  isOwner = true;
  isManager = false;

  constructor() { }

  ngOnInit(): void {
    
  }

  // Save the updated profile details
  saveProfile() {
    alert('Profile updated successfully!');
    // Add logic to save updated profile (e.g., send to backend)
  }

  // Cancel the editing and go back
  cancelEditing() {
    alert('Editing canceled!');
    // Add logic to navigate back to profile page or previous page
  }
}
