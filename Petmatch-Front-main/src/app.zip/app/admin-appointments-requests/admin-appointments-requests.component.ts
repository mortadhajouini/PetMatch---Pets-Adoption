import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-appointments-requests',
  templateUrl: './admin-appointments-requests.component.html',
  styleUrls: ['./admin-appointments-requests.component.css']
})
export class AdminAppointmentsRequestsComponent implements OnInit {
  // Sample appointment requests (replace with data from your backend)
  appointmentRequests = [
    { id: 1, title: 'Checkup for Max',  userName: 'John Doe', petName: 'Max' },
    { id: 2, title: 'Vaccination for Bella', userName: 'Jane Smith', petName: 'Bella' },
    { id: 3, title: 'Dental Check', userName: 'Chris Evans', petName: 'Charlie' }
  ];

  constructor() {}

  ngOnInit(): void {}

  // Function to accept an appointment request
  acceptRequest(request: any) {
    alert(`Appointment '${request.title}' accepted!`);
    // Remove the request from the list (for demonstration purposes)
    this.appointmentRequests = this.appointmentRequests.filter(r => r.id !== request.id);
    // Add backend logic to update the appointment status
  }

  // Function to decline an appointment request
  declineRequest(request: any) {
    alert(`Appointment '${request.title}' declined.`);
    // Remove the request from the list (for demonstration purposes)
    this.appointmentRequests = this.appointmentRequests.filter(r => r.id !== request.id);
    // Add backend logic to update the appointment status
  }
}
